package nosmoking;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MyPagePointListRepository extends CrudRepository<MyPagePointList, Long> {

    List<MyPagePointList> findByUserId(Long userId);
    List<MyPagePointList> findByPointId(Long pointId);
    List<MyPagePointList> findByUserId(Long userId);
    List<MyPagePointList> findByPointId(Long pointId);

}