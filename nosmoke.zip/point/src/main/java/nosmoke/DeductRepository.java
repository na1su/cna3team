package nosmoke;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface DeductRepository extends PagingAndSortingRepository<Deduct, Long>{


}