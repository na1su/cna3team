package nosmoking;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Check_table")
public class Check {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long checkInId;
    private Long userId;
    private Date checkInDate;
    private Long latitude;
    private Long longitude;
    private String status;
    private Long smokingAreaId;
    private String smokingAreaName;

    @PostPersist
    public void onPostPersist(){
        Checked checked = new Checked();
        BeanUtils.copyProperties(this, checked);
        checked.publishAfterCommit();

        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        nosmoking.external.SmokingArea smokingArea = new nosmoking.external.SmokingArea();
        // mappings goes here
        CheckApplication.applicationContext.getBean(nosmoking.external.SmokingAreaService.class)
            .smokingAreaChange(smokingArea);


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCheckInId() {
        return checkInId;
    }

    public void setCheckInId(Long checkInId) {
        this.checkInId = checkInId;
    }
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }
    public Long getLatitude() {
        return latitude;
    }

    public void setLatitude(Long latitude) {
        this.latitude = latitude;
    }
    public Long getLongitude() {
        return longitude;
    }

    public void setLongitude(Long longitude) {
        this.longitude = longitude;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public Long getSmokingAreaId() {
        return smokingAreaId;
    }

    public void setSmokingAreaId(Long smokingAreaId) {
        this.smokingAreaId = smokingAreaId;
    }
    public String getSmokingAreaName() {
        return smokingAreaName;
    }

    public void setSmokingAreaName(String smokingAreaName) {
        this.smokingAreaName = smokingAreaName;
    }




}
