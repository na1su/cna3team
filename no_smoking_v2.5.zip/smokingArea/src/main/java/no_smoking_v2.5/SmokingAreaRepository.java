package no_smoking_v2.5;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface SmokingAreaRepository extends PagingAndSortingRepository<SmokingArea, Long>{


}