package nosmoking;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CheckRepository extends PagingAndSortingRepository<Check, Long>{


}