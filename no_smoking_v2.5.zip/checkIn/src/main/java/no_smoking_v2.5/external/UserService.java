
package no_smoking_v2.5.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Date;

@FeignClient(name="user", url="http://user:8080")
public interface UserService {

    @RequestMapping(method= RequestMethod.GET, path="/users")
    public void queryUser(@RequestBody User user);

}