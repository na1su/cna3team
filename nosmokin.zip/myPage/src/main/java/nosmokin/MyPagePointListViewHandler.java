package nosmokin;

import nosmokin.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class MyPagePointListViewHandler {


    @Autowired
    private MyPagePointListRepository myPagePointListRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void whenRegisteredPoints_then_CREATE_1 (@Payload RegisteredPoints registeredPoints) {
        try {
            if (registeredPoints.isMe()) {
                // view 객체 생성
                MyPagePointList myPagePointList = new MyPagePointList();
                // view 객체에 이벤트의 Value 를 set 함
                myPagePointList.setUserId(registeredPoints.getUserId());
                myPagePointList.setPointId(registeredPoints.getPointId());
                myPagePointList.setPointValue(registeredPoints.getPointValue());
                // view 레파지 토리에 save
                myPagePointListRepository.save(myPagePointList);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whenAccumulatedPoints_then_UPDATE_1(@Payload AccumulatedPoints accumulatedPoints) {
        try {
            if (accumulatedPoints.isMe()) {
                // view 객체 조회
                List<MyPagePointList> myPagePointListList = myPagePointListRepository.findByUserId(accumulatedPoints.getUserId());
                for(MyPagePointList myPagePointList : myPagePointListList){
                    // view 객체에 이벤트의 eventDirectValue 를 set 함
                    myPagePointList.setPointValue(accumulatedPoints.getPointValue());
                    // view 레파지 토리에 save
                    myPagePointListRepository.save(myPagePointList);
                }
                List<MyPagePointList> myPagePointListList = myPagePointListRepository.findByPointId(accumulatedPoints.getPointId());
                for(MyPagePointList myPagePointList : myPagePointListList){
                    // view 객체에 이벤트의 eventDirectValue 를 set 함
                    myPagePointList.setPointValue(accumulatedPoints.getPointValue());
                    // view 레파지 토리에 save
                    myPagePointListRepository.save(myPagePointList);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenDeductedPoints_then_UPDATE_2(@Payload DeductedPoints deductedPoints) {
        try {
            if (deductedPoints.isMe()) {
                // view 객체 조회
                List<MyPagePointList> myPagePointListList = myPagePointListRepository.findByUserId(deductedPoints.getUserId());
                for(MyPagePointList myPagePointList : myPagePointListList){
                    // view 객체에 이벤트의 eventDirectValue 를 set 함
                    myPagePointList.setPointValue(deductedPoints.getPointValue());
                    // view 레파지 토리에 save
                    myPagePointListRepository.save(myPagePointList);
                }
                List<MyPagePointList> myPagePointListList = myPagePointListRepository.findByPointId(deductedPoints.getPointId());
                for(MyPagePointList myPagePointList : myPagePointListList){
                    // view 객체에 이벤트의 eventDirectValue 를 set 함
                    myPagePointList.setPointValue(deductedPoints.getPointValue());
                    // view 레파지 토리에 save
                    myPagePointListRepository.save(myPagePointList);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}