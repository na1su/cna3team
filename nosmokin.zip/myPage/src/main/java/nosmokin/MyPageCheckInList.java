package nosmokin;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="MyPageCheckInList_table")
public class MyPageCheckInList {

        @Id
        @GeneratedValue(strategy=GenerationType.AUTO)
        private Long id;
        private Long userId;
        private Long checkInId;
        private Date checkInDate;
        private String status;
        private Long smokingAreaId;
        private String smokingAreaName;


        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }
        public Long getCheckInId() {
            return checkInId;
        }

        public void setCheckInId(Long checkInId) {
            this.checkInId = checkInId;
        }
        public Date getCheckInDate() {
            return checkInDate;
        }

        public void setCheckInDate(Date checkInDate) {
            this.checkInDate = checkInDate;
        }
        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
        public Long getSmokingAreaId() {
            return smokingAreaId;
        }

        public void setSmokingAreaId(Long smokingAreaId) {
            this.smokingAreaId = smokingAreaId;
        }
        public String getSmokingAreaName() {
            return smokingAreaName;
        }

        public void setSmokingAreaName(String smokingAreaName) {
            this.smokingAreaName = smokingAreaName;
        }

}
