package nosmokin;

import nosmokin.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class MyPageCheckInListViewHandler {


    @Autowired
    private MyPageCheckInListRepository myPageCheckInListRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void whenCheckedInSmokingArea_then_CREATE_1 (@Payload CheckedInSmokingArea checkedInSmokingArea) {
        try {
            if (checkedInSmokingArea.isMe()) {
                // view 객체 생성
                MyPageCheckInList myPageCheckInList = new MyPageCheckInList();
                // view 객체에 이벤트의 Value 를 set 함
                myPageCheckInList.setUserId(checkedInSmokingArea.getUserId());
                myPageCheckInList.setCheckInId(checkedInSmokingArea.getCheckDate());
                myPageCheckInList.setCheckInDate(checkedInSmokingArea.getCheckDate());
                myPageCheckInList.setStatus(checkedInSmokingArea.getStatus());
                myPageCheckInList.setSmokingAreaId(checkedInSmokingArea.getSmokingAreaId());
                myPageCheckInList.setSmokingAreaName(checkedInSmokingArea.getSmokingAreaName());
                // view 레파지 토리에 save
                myPageCheckInListRepository.save(myPageCheckInList);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }



}