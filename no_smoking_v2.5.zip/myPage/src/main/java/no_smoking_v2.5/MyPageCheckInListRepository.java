package no_smoking_v2.5;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MyPageCheckInListRepository extends CrudRepository<MyPageCheckInList, Long> {


}