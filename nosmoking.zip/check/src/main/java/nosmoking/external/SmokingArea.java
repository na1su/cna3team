package nosmoking.external;

public class SmokingArea {

    private Long id;
    private Long smokingAreaId;
    private Long latitude;
    private Long longitude;
    private String smokingAreaName;
    private Integer checkInCount;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getSmokingAreaId() {
        return smokingAreaId;
    }
    public void setSmokingAreaId(Long smokingAreaId) {
        this.smokingAreaId = smokingAreaId;
    }
    public Long getLatitude() {
        return latitude;
    }
    public void setLatitude(Long latitude) {
        this.latitude = latitude;
    }
    public Long getLongitude() {
        return longitude;
    }
    public void setLongitude(Long longitude) {
        this.longitude = longitude;
    }
    public String getSmokingAreaName() {
        return smokingAreaName;
    }
    public void setSmokingAreaName(String smokingAreaName) {
        this.smokingAreaName = smokingAreaName;
    }
    public Integer getCheckInCount() {
        return checkInCount;
    }
    public void setCheckInCount(Integer checkInCount) {
        this.checkInCount = checkInCount;
    }

}
