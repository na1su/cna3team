package no_smoking_v2.5;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="MyPagePointList_table")
public class MyPagePointList {

        @Id
        @GeneratedValue(strategy=GenerationType.AUTO)
        private Long id;
        private Long userId;
        private Long pointId;
        private Integer pointValue;


        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }
        public Long getPointId() {
            return pointId;
        }

        public void setPointId(Long pointId) {
            this.pointId = pointId;
        }
        public Integer getPointValue() {
            return pointValue;
        }

        public void setPointValue(Integer pointValue) {
            this.pointValue = pointValue;
        }

}
