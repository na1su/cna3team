
package nosmokin.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Date;

@FeignClient(name="smokingArea", url="http://smokingArea:8080")
public interface SmokingAreaService {

    @RequestMapping(method= RequestMethod.GET, path="/smokingAreas")
    public void checkSmokingArea(@RequestBody SmokingArea smokingArea);

}