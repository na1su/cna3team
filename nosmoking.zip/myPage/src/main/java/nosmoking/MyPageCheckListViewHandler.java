package nosmoking;

import nosmoking.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class MyPageCheckListViewHandler {


    @Autowired
    private MyPageCheckListRepository myPageCheckListRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void whenChecked_then_CREATE_1 (@Payload Checked checked) {
        try {
            if (checked.isMe()) {
                // view 객체 생성
                MyPageCheckList myPageCheckList = new MyPageCheckList();
                // view 객체에 이벤트의 Value 를 set 함
                myPageCheckList.setUserId(checked.getUserId());
                myPageCheckList.setCheckInId(checked.getCheckDate());
                myPageCheckList.setCheckInDate(checked.getCheckDate());
                myPageCheckList.setStatus(checked.getStatus());
                myPageCheckList.setSmokingAreaId(checked.getSmokingAreaId());
                myPageCheckList.setSmokingAreaName(checked.getSmokingAreaName());
                // view 레파지 토리에 save
                myPageCheckListRepository.save(myPageCheckList);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }



}