package nosmoke;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface EarnRepository extends PagingAndSortingRepository<Earn, Long>{


}