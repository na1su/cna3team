package nosmokin;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface SmokingAreaRepository extends PagingAndSortingRepository<SmokingArea, Long>{


}